package test;

import static org.junit.Assert.*;
import factory.ComposantFactory;
import itf.ICarte;
import itf.iCartes;

import org.junit.Test;

public class TestInit {

	@Test
	public void test() {
		iCartes cartes =  ComposantFactory.createCartes();
		
		//for (ICarte c : cartes.lister()) {
			//System.out.println(c.getDesc());
		//}
	}

}
