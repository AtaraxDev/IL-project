/**
 * 
 */
package factory;

import carte.GestionCarte;
import itf.iCartes;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author 3770098
 * @generated "UML vers Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class ComposantFactory {

	public static iCartes createCartes() {
		
		return new GestionCarte();
	}
}