package CompProduit;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import intefaces.ICompte;
import intefaces.IGestProduits;

import org.junit.Assert;
import org.junit.Test;

public class AcheterContenu2 {

	@Test
	public void sequanceNominal() {
		ICompte compte = new CompteBouchon();
		IGestProduits gp = new GestProduitImplementation(compte);
		
		Set<String> produits = gp.listerProduits();
		Assert.assertTrue(produits.contains("M58"));
		Assert.assertTrue(produits.contains("M65"));
		Assert.assertTrue(!produits.contains("M42"));
		
		String nomProduit  = gp.getNomProduit("M58");
		Integer prixProduit = gp.getPrixProduit("M58");
		
		Assert.assertTrue(gp.ajoutezPanier(1, "007", "M58"));	
		
		Integer prixPanier = gp.calculerPrixPanier("007");
		Assert.assertTrue(prixPanier == 20);
		
		Assert.assertTrue(!gp.valideAchat("007", 19));
		Assert.assertTrue(gp.valideAchat("007", 20));
	}

}

/**
 * Cette classe est bouchon.
 */

class CompteBouchon implements ICompte {

	public Boolean declencherPayement(String idJoueur) {
		return idJoueur.equals("007");
	}
	public Boolean ajouterProduitAuCompte(String idProduit, String idJouer) {return null;}
	public Set<String> listerProduitsDispoDuCompte(Object idJoueur) {return null;}
	public Boolean utiliserProduit(String idProduit) { return null;}
	public Boolean verifierCbAssocie(String idJoueur) {return null;}
	public void inscrire(String nom, String pass, String email) {}
	public Boolean deconnecter(Object idJoueur) {return null;}
	public Boolean connexion(String nomCompte, String pass) {return null;}
	public void setDevise(String devise) {}
	public Float getSolde(Object idJoueur) {return null;}
	public void setCb(String idJoueur, String cbNumero) {}
}

/**
 * 
 * Cette classe simule un vraie implementation.
 * 
 */
class GestProduitImplementation implements IGestProduits {
	private ICompte comp;
	
	public GestProduitImplementation(ICompte ic) {
		this.comp = ic;
	}
	@Override
	public boolean valideAchat(String idJoueur, float montant) {
		// ...
		return comp.declencherPayement(idJoueur);
	}
	
	@Override
	public Boolean ajoutezPanier(Integer quantite, String idJoueur,
			String idProduct) {
		return true;
	}

	@Override
	public Set<String> listerProduits() {
		Set<String> s = new HashSet<>();
		s.add("M58");
		s.add("M65");
		return s;
	}

	@Override
	public Integer getPrixProduit(String idProduit) {
		return 20;
	}

	@Override
	public Set<String> getPanier(String idJoueur) {
		return null;
	}

	@Override
	public String getNomProduit(String idProduit) {
		return "Super carte";
	}

	@Override
	public Integer calculerPrixPanier(String idJoueur) {
		return 20;
	}
	
}