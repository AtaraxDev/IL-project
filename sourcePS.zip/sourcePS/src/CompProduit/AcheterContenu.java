package CompProduit;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import intefaces.IGestProduits;

import org.junit.Assert;
import org.junit.Test;

public class AcheterContenu {

	@Test
	public void sequanceNominal() {
		IGestProduits gp = new GestProduitBouchon();
		
		Set<String> produits = gp.listerProduits();
		Assert.assertTrue(produits.contains("M58"));
		Assert.assertTrue(produits.contains("M65"));
		Assert.assertTrue(!produits.contains("M42"));
		
		String nomProduit  = gp.getNomProduit("M58");
		Integer prixProduit = gp.getPrixProduit("M58");
		
		Assert.assertTrue(gp.ajoutezPanier(1, "007", "M58"));	
		
		Integer prixPanier = gp.calculerPrixPanier("007");
		Assert.assertTrue(prixPanier == 20);
		
		Assert.assertTrue(!gp.valideAchat("007", 19));
		Assert.assertTrue(gp.valideAchat("007", 20));
		
	}

}

class GestProduitBouchon implements IGestProduits{

	@Override
	public Boolean ajoutezPanier(Integer quantite, String idJoueur,
			String idProduct) {
		return true;
	}

	@Override
	public boolean valideAchat(String idJoueur, float montant) {
		return (idJoueur.equals("007") && (montant >= 20));
	}

	@Override
	public Set<String> listerProduits() {
		Set<String> s = new HashSet<>();
		s.add("M58");
		s.add("M65");
		return s;
	}

	@Override
	public Integer getPrixProduit(String idProduit) {
		return 20;
	}

	@Override
	public Set<String> getPanier(String idJoueur) {
		return null;
	}

	@Override
	public String getNomProduit(String idProduit) {
		return "Super carte";
	}

	@Override
	public Integer calculerPrixPanier(String idJoueur) {
		return 20;
	}
	
}